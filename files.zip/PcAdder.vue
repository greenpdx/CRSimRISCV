<template>
  <div class="adder" :class="{ 'adder--active': active }">

    <div class="adder__header">
      <span class="adder__title">Adder</span>
      <span class="adder__subtitle">PC + 4</span>
    </div>

    <div class="adder__body">

      <div class="adder__row">
        <span class="adder__operand">{{ fmtHex(pc) }}</span>
        <span class="adder__op-symbol">+</span>
        <span class="adder__immediate">4</span>
      </div>

      <div class="adder__divider"/>

      <div class="adder__row adder__row--result">
        <span class="adder__result-label">=</span>
        <span class="adder__result">{{ fmtHex(result) }}</span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  /** Current PC fed into the adder */
  pc: number
  /** True when adder output is being used this cycle */
  active?: boolean
}>()

const result = computed(() => (props.pc >>> 0) + 4)

const fmtHex = (v: number) =>
  '0x' + (v >>> 0).toString(16).padStart(8, '0')
</script>

<style scoped>
.adder {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 180px;
  transition: box-shadow 0.15s ease;
}
.adder--active {
  box-shadow: 0 0 0 2px #00e6a6;
}

/* Header */
.adder__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.adder__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 2px;
  color: #ffffff;
  text-transform: uppercase;
}
.adder__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Body */
.adder__body {
  padding: 6px 10px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.adder__row {
  display: flex;
  align-items: center;
  gap: 6px;
}
.adder__row--result {
  padding-top: 1px;
}

.adder__operand {
  font-size: 11px;
  color: #0a2030;
  font-weight: 500;
  letter-spacing: 0.5px;
}
.adder__op-symbol {
  font-size: 12px;
  color: #6a9ab0;
  font-weight: 600;
}
.adder__immediate {
  font-size: 11px;
  color: #009977;
  font-weight: 600;
}

.adder__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 1px 0;
}

.adder__result-label {
  font-size: 12px;
  color: #6a9ab0;
  font-weight: 600;
  width: 12px;
}
.adder__result {
  font-size: 12px;
  color: #006080;
  font-weight: 700;
  letter-spacing: 0.5px;
}
</style>
