<template>
  <tr
    class="mem-row"
    :class="{
      'mem-row--active': word.active,
      'mem-row--stripe': stripe,
    }"
  >
    <!-- Fixed address — never changes, not selectable -->
    <td class="mem-row__addr">{{ addrHex }}</td>

    <!-- Hex bytes — mutable, updated by simulator -->
    <td class="mem-row__bytes">{{ bytesDisplay }}</td>

    <!-- ASM (ROM) or decimal (RAM) — optional, slot-driven by parent -->
    <td v-if="showAnnotation" class="mem-row__annotation">
      {{ word.asm ?? decValue }}
    </td>

    <!-- Active indicator dot -->
    <td class="mem-row__dot">
      <span v-if="word.active" class="mem-row__dot-inner" />
    </td>
  </tr>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { MemoryWord } from '../../types/cpu'

const props = defineProps<{
  word: MemoryWord
  /** 'rom' shows asm column, 'ram' shows signed decimal column */
  kind: 'rom' | 'ram'
  /** Alternating background stripe */
  stripe?: boolean
}>()

/** Whether to render the annotation (asm/dec) column */
const showAnnotation = computed(() => props.kind === 'rom' || props.kind === 'ram')

/** Zero-padded 8-digit hex address */
const addrHex = computed(() =>
  '0x' + props.word.address.toString(16).padStart(8, '0')
)

/**
 * Display the word value as spaced byte pairs, big-endian visual order.
 * e.g. 0x00100513 → "00 10 05 13"
 */
const bytesDisplay = computed(() => {
  const w = props.word.value >>> 0
  const b3 = (w >>> 24) & 0xff
  const b2 = (w >>> 16) & 0xff
  const b1 = (w >>>  8) & 0xff
  const b0 =  w         & 0xff
  return [b3, b2, b1, b0]
    .map(b => b.toString(16).padStart(2, '0'))
    .join(' ')
})

/** Signed 32-bit decimal — shown in RAM annotation column */
const decValue = computed(() => (props.word.value | 0).toString(10))
</script>

<style scoped>
.mem-row {
  transition: background-color 0.15s ease;
}
.mem-row--stripe {
  background-color: #e8f8fb;
}
.mem-row--active {
  background-color: #d8f0ff !important;
  font-weight: 600;
}

/* Address — fixed, dimmed, non-selectable */
.mem-row__addr {
  padding: 2px 6px;
  font-size: 10px;
  color: #6a9ab0;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  white-space: nowrap;
  user-select: none;
  min-width: 88px;
}

/* Hex bytes */
.mem-row__bytes {
  padding: 2px 8px;
  font-size: 10px;
  color: #0a2030;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  white-space: nowrap;
  min-width: 88px;
}

/* ASM (ROM) or decimal (RAM) */
.mem-row__annotation {
  padding: 2px 8px;
  font-size: 10px;
  color: #2a6090;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  white-space: nowrap;
}

/* Active dot */
.mem-row__dot {
  padding: 0 4px;
  width: 10px;
}
.mem-row__dot-inner {
  display: inline-block;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #38bdf8;
}
</style>
