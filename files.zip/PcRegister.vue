<template>
  <div class="pc" :class="{ 'pc--active': active }">

    <div class="pc__header">
      <span class="pc__title">PC</span>
      <span class="pc__subtitle">Program Counter</span>
    </div>

    <div class="pc__body">
      <!-- Current PC -->
      <div class="pc__row">
        <span class="pc__label">current</span>
        <span class="pc__value pc__value--current">{{ fmtHex(pc) }}</span>
      </div>

      <!-- Next PC -->
      <div class="pc__row">
        <span class="pc__label">next</span>
        <span
          class="pc__value pc__value--next"
          :class="{ 'pc__value--branch': isBranch }"
        >{{ fmtHex(nextPc) }}</span>
        <span v-if="isBranch" class="pc__branch-badge">branch</span>
        <span v-else class="pc__seq-badge">+4</span>
      </div>
    </div>

  </div>
</template>

<script setup lang="ts">
const props = defineProps<{
  /** Current PC value */
  pc: number
  /** Next PC value (PC+4 or branch target) */
  nextPc: number
  /** True when PC is being written this cycle */
  active?: boolean
}>()

const isBranch = computed(() => props.nextPc !== props.pc + 4)

const fmtHex = (v: number) =>
  '0x' + (v >>> 0).toString(16).padStart(8, '0')
</script>

<script lang="ts">
import { computed } from 'vue'
</script>

<style scoped>
.pc {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 240px;
  transition: box-shadow 0.15s ease;
}
.pc--active {
  box-shadow: 0 0 0 2px #f59e0b;
}

/* Header */
.pc__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.pc__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 2px;
  color: #ffffff;
  text-transform: uppercase;
}
.pc__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Body */
.pc__body {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 6px 10px;
}

.pc__row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pc__label {
  font-size: 9px;
  color: #6a9ab0;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 44px;
  flex-shrink: 0;
}

.pc__value {
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 1px;
}
.pc__value--current { color: #0a2030; }
.pc__value--next    { color: #2a6a80; }
.pc__value--branch  { color: #b05000; }

.pc__branch-badge {
  font-size: 8px;
  padding: 1px 5px;
  border-radius: 2px;
  background: #fff0d0;
  color: #804000;
  font-weight: 600;
  letter-spacing: 1px;
  text-transform: uppercase;
}
.pc__seq-badge {
  font-size: 8px;
  padding: 1px 5px;
  border-radius: 2px;
  background: #e0f4f8;
  color: #006080;
  letter-spacing: 1px;
}
</style>
