<template>
  <div class="aluctl" :class="{ 'aluctl--active': active }">

    <div class="aluctl__header">
      <span class="aluctl__title">ALU Control</span>
      <span class="aluctl__subtitle">{{ mnemonic }} · {{ fmtBin(aluControlOut, 4) }}</span>
    </div>

    <div class="aluctl__body">

      <!-- Inputs -->
      <div class="aluctl__row">
        <span class="aluctl__label">ALUOp</span>
        <span class="aluctl__val">{{ fmtBin(aluOp, 2) }}</span>
        <span class="aluctl__hint">{{ ALU_OP_LABEL[aluOp] }}</span>
      </div>
      <div class="aluctl__row">
        <span class="aluctl__label">funct3</span>
        <span class="aluctl__val">{{ fmtBin(funct3, 3) }}</span>
      </div>
      <div class="aluctl__row">
        <span class="aluctl__label">funct7[30]</span>
        <span class="aluctl__val">{{ funct7b30 }}</span>
      </div>

      <div class="aluctl__divider" />

      <!-- Output -->
      <div class="aluctl__row aluctl__row--out">
        <span class="aluctl__label">aluCtrl</span>
        <span class="aluctl__out-val">{{ fmtBin(aluControlOut, 4) }}</span>
        <span class="aluctl__out-mnem">{{ mnemonic }}</span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { computeAluControl } from '../../../data/aluControlData'
import { ALU_OP_LABEL } from '../../../data/controlData'

const props = defineProps<{
  /** 2-bit ALUOp from main decoder */
  aluOp:     0 | 1 | 2
  /** funct3 from instruction[14:12] */
  funct3:    number
  /** instruction[30] — distinguishes ADD/SUB and SRL/SRA */
  funct7b30: 0 | 1
  /** True when LUI opcode — forces LUI pass-through */
  isLui?:    boolean
  /** True while computing this cycle */
  active?:   boolean
}>()

const aluControlOut = computed(() =>
  computeAluControl(props.aluOp, props.funct3, props.funct7b30, props.isLui)
)

const mnemonic = computed(() => {
  const code = aluControlOut.value
  const names: Record<number, string> = {
    0b0000: 'AND',  0b0001: 'OR',   0b0010: 'ADD',  0b0011: 'XOR',
    0b0100: 'SLL',  0b0101: 'SRL',  0b0110: 'SUB',  0b0111: 'SLT',
    0b1000: 'SLTU', 0b1001: 'SRA',  0b1010: 'LUI',
  }
  return names[code] ?? '?'
})

const fmtBin = (v: number, bits: number) =>
  (v >>> 0).toString(2).padStart(bits, '0')
</script>

<style scoped>
.aluctl {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 200px;
  transition: box-shadow 0.15s ease;
}
.aluctl--active {
  box-shadow: 0 0 0 2px #f59e0b;
}

.aluctl__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.aluctl__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.aluctl__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

.aluctl__body {
  padding: 5px 10px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.aluctl__row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.aluctl__row--out {
  padding-top: 2px;
}

.aluctl__label {
  font-size: 9px;
  color: #6a9ab0;
  width: 68px;
  flex-shrink: 0;
}
.aluctl__val {
  font-size: 10px;
  color: #0a2030;
  font-weight: 500;
  letter-spacing: 1px;
}
.aluctl__hint {
  font-size: 8px;
  color: #aaaaaa;
}

.aluctl__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 2px 0;
}

.aluctl__out-val {
  font-size: 12px;
  font-weight: 700;
  color: #004060;
  letter-spacing: 1px;
}
.aluctl__out-mnem {
  font-size: 11px;
  font-weight: 700;
  color: #f59e0b;
}
</style>
