<template>
  <div class="immgen" :class="{ 'immgen--active': active }">

    <div class="immgen__header">
      <span class="immgen__title">Imm Generator</span>
      <span class="immgen__subtitle">{{ formatDef?.name ?? '—' }}-type</span>
    </div>

    <div class="immgen__body">

      <!-- Format + bit pattern -->
      <div class="immgen__format-row">
        <span class="immgen__format-name">{{ formatDef?.name ?? '?' }}</span>
        <span class="immgen__format-bits">{{ formatDef?.bits ?? '—' }}</span>
      </div>

      <div class="immgen__divider" />

      <!-- Result -->
      <div class="immgen__result-row">
        <span class="immgen__result-label">imm</span>
        <span class="immgen__result-hex">{{ fmtHex(immediate) }}</span>
        <span class="immgen__result-dec">({{ immediate | 0 }})</span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { extractImmediate, IMM_FORMAT_BY_SEL } from '../../../data/immData'
import type { ImmSel } from '../../../data/immData'

const props = defineProps<{
  /** Full 32-bit instruction word */
  instruction: number
  /** ImmSel[2:0] from decoder — selects extraction format */
  immSel: ImmSel
  /** True while extracting this cycle */
  active?: boolean
}>()

const formatDef = computed(() => IMM_FORMAT_BY_SEL.get(props.immSel))

const immediate = computed(() =>
  extractImmediate(props.instruction, props.immSel)
)

const fmtHex = (v: number) =>
  '0x' + (v >>> 0).toString(16).padStart(8, '0')
</script>

<style scoped>
.immgen {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 200px;
  transition: box-shadow 0.15s ease;
}
.immgen--active {
  box-shadow: 0 0 0 2px #00e6a6;
}

.immgen__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.immgen__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.immgen__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

.immgen__body {
  padding: 5px 10px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.immgen__format-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.immgen__format-name {
  font-size: 12px;
  font-weight: 700;
  color: #cc2222;
  width: 28px;
  flex-shrink: 0;
}
.immgen__format-bits {
  font-size: 9px;
  color: #6a9ab0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.immgen__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 2px 0;
}

.immgen__result-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.immgen__result-label {
  font-size: 9px;
  color: #6a9ab0;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 20px;
}
.immgen__result-hex {
  font-size: 12px;
  font-weight: 700;
  color: #004060;
}
.immgen__result-dec {
  font-size: 9px;
  color: #888888;
}
</style>
