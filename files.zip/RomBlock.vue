<template>
  <div class="rom">

    <div class="rom__header">
      <span class="rom__title">Instruction Memory</span>
      <span class="rom__subtitle">ROM · {{ words.length }} words</span>
    </div>

    <!-- Column headers -->
    <table class="rom__table">
      <thead>
        <tr class="rom__col-headers">
          <th class="rom__th rom__th--addr">Address</th>
          <th class="rom__th rom__th--bytes">Bytes</th>
          <th class="rom__th rom__th--asm">Assembly</th>
          <th class="rom__th rom__th--dot"></th>
        </tr>
      </thead>
    </table>

    <!-- Scrollable body -->
    <div class="rom__scroll" ref="scrollEl">
      <table class="rom__table">
        <tbody>
          <MemoryRow
            v-for="(word, i) in words"
            :key="word.address"
            :word="word"
            kind="rom"
            :stripe="i % 2 === 1"
          />
        </tbody>
      </table>
    </div>

    <!-- Footer: current PC word -->
    <div class="rom__footer">
      <span class="rom__footer-label">PC →</span>
      <span class="rom__footer-addr">{{ fmtHex(activeAddress) }}</span>
      <span class="rom__footer-asm">{{ activeAsm }}</span>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick } from 'vue'
import MemoryRow from '../rows/MemoryRow.vue'
import type { MemoryWord } from '../../../types/cpu'

const props = defineProps<{
  /** Full ROM contents — all words, in address order */
  words: MemoryWord[]
  /** Current PC value — used to auto-scroll to active row */
  pc: number
}>()

const scrollEl = ref<HTMLDivElement | null>(null)

const fmtHex = (v: number) =>
  '0x' + (v >>> 0).toString(16).padStart(8, '0')

/** The word currently at the PC */
const activeWord = computed(() =>
  props.words.find(w => w.active) ?? null
)

const activeAddress = computed(() =>
  activeWord.value?.address ?? props.pc
)

const activeAsm = computed(() =>
  activeWord.value?.asm ?? '—'
)

/**
 * Auto-scroll so the active (PC) row stays visible.
 * Fires whenever the active word changes.
 */
watch(activeWord, async () => {
  await nextTick()
  if (!scrollEl.value || !activeWord.value) return

  const rowIndex = props.words.findIndex(w => w.active)
  if (rowIndex < 0) return

  // Each row is ~18px tall; keep active row in the middle third of the viewport
  const rowH   = 18
  const viewH  = scrollEl.value.clientHeight
  const target = rowIndex * rowH - viewH / 2 + rowH / 2

  scrollEl.value.scrollTo({ top: Math.max(0, target), behavior: 'smooth' })
})
</script>

<style scoped>
.rom {
  display: flex;
  flex-direction: column;
  background: #4ec3d5;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 320px;
}

/* Header */
.rom__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
  flex-shrink: 0;
}
.rom__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.rom__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Column headers */
.rom__table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}
.rom__col-headers {
  background: #3ab8cc;
}
.rom__th {
  padding: 2px 6px;
  font-size: 9px;
  font-weight: 500;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: #d0f0f8;
  border-bottom: 1px solid #2aacbe;
  text-align: left;
}
.rom__th--addr  { width: 90px; }
.rom__th--bytes { width: 90px; }
.rom__th--asm   { }
.rom__th--dot   { width: 16px; }

/* Scrollable body */
.rom__scroll {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 280px;
}

/* Footer */
.rom__footer {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 3px 8px;
  background: #2aacbe;
  min-height: 22px;
  flex-shrink: 0;
}
.rom__footer-label {
  font-size: 9px;
  color: #90d8e4;
}
.rom__footer-addr {
  font-size: 10px;
  color: #ffffff;
  font-weight: 600;
}
.rom__footer-asm {
  font-size: 10px;
  color: #c0eaf2;
  flex: 1;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
