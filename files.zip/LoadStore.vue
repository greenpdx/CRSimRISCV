<template>
  <div class="ls" :class="[`ls--${op}`, { 'ls--active': op !== 'idle' }]">

    <div class="ls__header">
      <span class="ls__title">Load / Store</span>
      <span class="ls__subtitle">{{ opLabel }}</span>
    </div>

    <div class="ls__body">

      <!-- Address -->
      <div class="ls__row">
        <span class="ls__label">addr</span>
        <span class="ls__value">{{ fmtHex(address) }}</span>
      </div>

      <!-- Width -->
      <div class="ls__row">
        <span class="ls__label">width</span>
        <span class="ls__width-badge" :class="`ls__width-badge--${width}`">
          {{ width.toUpperCase() }}
        </span>
        <span class="ls__width-hint">{{ widthBits }} bit{{ widthBits > 8 ? 's' : '' }}</span>
      </div>

      <!-- Write data (store only) -->
      <div v-if="op === 'store'" class="ls__row">
        <span class="ls__label">wdata</span>
        <span class="ls__value">{{ fmtHex(writeData) }}</span>
      </div>

      <div class="ls__divider" />

      <!-- Read data (load only) -->
      <div v-if="op === 'load'" class="ls__row ls__row--result">
        <span class="ls__label">rdata</span>
        <span class="ls__result">{{ fmtHex(readData) }}</span>
        <span class="ls__signed-hint">{{ signedLabel }}</span>
      </div>

      <!-- Store confirmation -->
      <div v-if="op === 'store'" class="ls__row ls__row--result">
        <span class="ls__label">stored</span>
        <span class="ls__result">{{ fmtHex(writeData) }}</span>
        <span class="ls__addr-hint">→ {{ fmtHex(address) }}</span>
      </div>

      <!-- Idle -->
      <div v-if="op === 'idle'" class="ls__row ls__row--result">
        <span class="ls__idle">no memory access</span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

export type LoadStoreOp   = 'idle' | 'load' | 'store'
export type AccessWidth   = 'b' | 'h' | 'w'    // byte / halfword / word
export type LoadSigned    = 'signed' | 'unsigned'

const props = defineProps<{
  op:        LoadStoreOp
  /** Effective address (ALU result) */
  address:   number
  /** Byte / halfword / word */
  width:     AccessWidth
  /** Signed or unsigned extension for loads */
  loadSign?: LoadSigned
  /** Data to write (store) */
  writeData?: number
  /** Data read from memory (load) — set by simulator after memory access */
  readData?:  number
}>()

const opLabel = computed(() => {
  if (props.op === 'idle')  return 'idle'
  if (props.op === 'load')  return `L${props.width.toUpperCase()}${props.loadSign === 'unsigned' ? 'U' : ''}`
  return `S${props.width.toUpperCase()}`
})

const widthBits = computed(() => ({ b: 8, h: 16, w: 32 }[props.width]))

const signedLabel = computed(() =>
  props.loadSign === 'unsigned' ? 'zero-ext' : 'sign-ext'
)

const fmtHex = (v = 0) => '0x' + (v >>> 0).toString(16).padStart(8, '0')
</script>

<style scoped>
.ls {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 210px;
  transition: box-shadow 0.15s, border-color 0.15s;
}
.ls--load  { border-color: #38bdf8; box-shadow: 0 0 0 2px #bde8ff; }
.ls--store { border-color: #f59e0b; box-shadow: 0 0 0 2px #fff0b0; }

/* Header */
.ls__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
  transition: background 0.15s;
}
.ls--load  .ls__header { background: #0099cc; }
.ls--store .ls__header { background: #cc8800; }

.ls__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.ls__subtitle {
  font-size: 10px;
  font-weight: 700;
  color: #ffffff;
  letter-spacing: 1px;
}

/* Body */
.ls__body {
  padding: 5px 10px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.ls__row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ls__row--result { padding-top: 2px; }

.ls__label {
  font-size: 9px;
  color: #6a9ab0;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 40px;
  flex-shrink: 0;
}
.ls__value {
  font-size: 11px;
  color: #0a2030;
  letter-spacing: 0.5px;
}

/* Width badge */
.ls__width-badge {
  font-size: 9px;
  font-weight: 700;
  padding: 1px 5px;
  border-radius: 2px;
  letter-spacing: 1px;
}
.ls__width-badge--b { background: #e0f0ff; color: #004080; }
.ls__width-badge--h { background: #e0f8e0; color: #004020; }
.ls__width-badge--w { background: #fff8e0; color: #604000; }

.ls__width-hint {
  font-size: 8px;
  color: #aaaaaa;
}

.ls__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 2px 0;
}

.ls__result {
  font-size: 12px;
  font-weight: 700;
  color: #004060;
  letter-spacing: 0.5px;
}
.ls__signed-hint {
  font-size: 8px;
  color: #888888;
}
.ls__addr-hint {
  font-size: 8px;
  color: #888888;
}
.ls__idle {
  font-size: 9px;
  color: #aaaaaa;
}
</style>
