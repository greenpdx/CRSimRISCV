<template>
  <div class="alu" :class="{ 'alu--active': active }">

    <div class="alu__header">
      <span class="alu__title">ALU</span>
      <span class="alu__subtitle">{{ opDef?.mnemonic ?? '—' }} · ctrl {{ fmtCode(aluControl) }}</span>
    </div>

    <div class="alu__body">

      <!-- Operand A -->
      <div class="alu__row">
        <span class="alu__port-label">A</span>
        <span class="alu__operand">{{ fmtHex(operandA) }}</span>
      </div>

      <!-- Operation -->
      <div class="alu__op-row">
        <span class="alu__port-label"></span>
        <span class="alu__op-expr">{{ opDef?.expression ?? '?' }}</span>
      </div>

      <!-- Operand B -->
      <div class="alu__row">
        <span class="alu__port-label">B</span>
        <span class="alu__operand">{{ fmtHex(operandB) }}</span>
      </div>

      <div class="alu__divider" />

      <!-- Result -->
      <div class="alu__row alu__row--result">
        <span class="alu__port-label">R</span>
        <span class="alu__result">{{ fmtHex(computed_.result) }}</span>
      </div>

      <!-- Flags -->
      <div class="alu__flags">
        <span class="alu__flag" :class="{ 'alu__flag--set': computed_.flags.zero }">Z</span>
        <span class="alu__flag" :class="{ 'alu__flag--set': computed_.flags.negative }">N</span>
        <span class="alu__flag" :class="{ 'alu__flag--set': computed_.flags.carry }">C</span>
        <span class="alu__flag" :class="{ 'alu__flag--set': computed_.flags.overflow }">V</span>
        <span v-if="opDef?.isBranchOp" class="alu__branch-out">
          branch {{ branchTaken ? '✓' : '✗' }}
        </span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { aluCompute, ALU_OP_BY_CODE } from '../../../data/aluData'

const props = defineProps<{
  /** 4-bit ALU control code from ALU control unit */
  aluControl: number
  operandA:   number
  operandB:   number
  /** True when ALU is computing this cycle */
  active?: boolean
}>()

const opDef = computed(() => ALU_OP_BY_CODE.get(props.aluControl))

const computed_ = computed(() =>
  aluCompute(props.aluControl, props.operandA, props.operandB)
)

/** Branch taken = zero flag set (BEQ) or negative (BLT), resolved by control */
const branchTaken = computed(() => computed_.value.flags.zero)

const fmtHex  = (v: number) => '0x' + (v >>> 0).toString(16).padStart(8, '0')
const fmtCode = (v: number) => v.toString(2).padStart(4, '0')
</script>

<style scoped>
.alu {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 220px;
  transition: box-shadow 0.15s ease;
}
.alu--active {
  box-shadow: 0 0 0 2px #f59e0b;
}

/* Header */
.alu__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.alu__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 2px;
  color: #ffffff;
  text-transform: uppercase;
}
.alu__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Body */
.alu__body {
  padding: 5px 10px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.alu__row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.alu__row--result { padding-top: 2px; }

.alu__port-label {
  font-size: 9px;
  color: #6a9ab0;
  font-weight: 600;
  width: 12px;
  flex-shrink: 0;
}

.alu__operand {
  font-size: 11px;
  color: #0a2030;
  letter-spacing: 0.5px;
}

.alu__op-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 1px 0;
}
.alu__op-expr {
  font-size: 9px;
  color: #2a6a80;
  font-style: italic;
}

.alu__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 2px 0;
}

.alu__result {
  font-size: 13px;
  color: #004060;
  font-weight: 700;
  letter-spacing: 0.5px;
}

/* Flags */
.alu__flags {
  display: flex;
  align-items: center;
  gap: 4px;
  padding-top: 3px;
}
.alu__flag {
  font-size: 9px;
  font-weight: 600;
  padding: 1px 5px;
  border-radius: 2px;
  background: #f0f0f0;
  color: #aaaaaa;
  letter-spacing: 1px;
  transition: background 0.1s, color 0.1s;
}
.alu__flag--set {
  background: #bde8ff;
  color: #004070;
}
.alu__branch-out {
  margin-left: 6px;
  font-size: 9px;
  color: #cc6600;
  font-weight: 600;
}
</style>
