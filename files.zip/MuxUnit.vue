<template>
  <div class="mux" :class="{ 'mux--active': active }">

    <div class="mux__header">
      <span class="mux__title">MUX</span>
      <span class="mux__subtitle">{{ label }}</span>
    </div>

    <div class="mux__body">

      <!-- Input ports -->
      <div class="mux__inputs">
        <div
          v-for="(input, i) in inputs"
          :key="i"
          class="mux__input"
          :class="{ 'mux__input--selected': i === select }"
        >
          <span class="mux__input-index">{{ i }}</span>
          <span class="mux__input-name">{{ input.name }}</span>
          <span class="mux__input-value">{{ fmtValue(input.value, input.bits) }}</span>
          <span v-if="i === select" class="mux__input-sel-dot" />
        </div>
      </div>

      <!-- Select line -->
      <div class="mux__select-row">
        <span class="mux__select-label">sel</span>
        <span class="mux__select-value">{{ select }}</span>
      </div>

      <div class="mux__divider" />

      <!-- Output -->
      <div class="mux__output-row">
        <span class="mux__output-label">out</span>
        <span class="mux__output-value">{{ fmtValue(outputValue, outputBits) }}</span>
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

export interface MuxInput {
  /** Port name shown in the UI, e.g. 'PC+4', 'branch', 'rs2', 'imm' */
  name: string
  /** Current value on this input */
  value: number
  /** Bit width of this input */
  bits: number
}

const props = defineProps<{
  /** Human label for this mux, e.g. 'PC Sel', 'ALU Src B', 'WB Sel' */
  label: string
  /** All input ports */
  inputs: MuxInput[]
  /** Index of the currently selected input (0-based) */
  select: number
  /** True when this mux output is being used this cycle */
  active?: boolean
}>()

/** Output value is simply the selected input's value */
const outputValue = computed(() =>
  props.inputs[props.select]?.value ?? 0
)

/** Output bit width follows selected input */
const outputBits = computed(() =>
  props.inputs[props.select]?.bits ?? 32
)

/** Format a value according to its bit width */
function fmtValue(value: number, bits: number): string {
  if (bits === 1) return value ? '1' : '0'
  if (bits <= 8)  return '0x' + (value & 0xff).toString(16).padStart(2, '0')
  if (bits <= 16) return '0x' + (value & 0xffff).toString(16).padStart(4, '0')
  return '0x' + (value >>> 0).toString(16).padStart(8, '0')
}
</script>

<style scoped>
.mux {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 180px;
  transition: box-shadow 0.15s ease;
}
.mux--active {
  box-shadow: 0 0 0 2px #f59e0b;
}

/* Header */
.mux__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
}
.mux__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 2px;
  color: #ffffff;
  text-transform: uppercase;
}
.mux__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Body */
.mux__body {
  padding: 5px 8px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

/* Inputs */
.mux__inputs {
  display: flex;
  flex-direction: column;
  gap: 1px;
}
.mux__input {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 2px 4px;
  border-radius: 2px;
  transition: background 0.1s;
}
.mux__input--selected {
  background: #e8f8fb;
}

.mux__input-index {
  font-size: 8px;
  color: #aaaaaa;
  width: 8px;
  flex-shrink: 0;
}
.mux__input-name {
  font-size: 9px;
  color: #6a9ab0;
  width: 48px;
  flex-shrink: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.mux__input-value {
  font-size: 10px;
  color: #0a2030;
  flex: 1;
  text-align: right;
}
.mux__input--selected .mux__input-name  { color: #006080; font-weight: 600; }
.mux__input--selected .mux__input-value { color: #004060; font-weight: 600; }

.mux__input-sel-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: #f59e0b;
  flex-shrink: 0;
}

/* Select row */
.mux__select-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 2px 4px;
}
.mux__select-label {
  font-size: 9px;
  color: #cc2222;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 18px;
}
.mux__select-value {
  font-size: 10px;
  color: #cc2222;
  font-weight: 600;
}

.mux__divider {
  height: 1px;
  background: #d0e8ef;
  margin: 2px 0;
}

/* Output row */
.mux__output-row {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 2px 4px;
}
.mux__output-label {
  font-size: 9px;
  color: #6a9ab0;
  text-transform: uppercase;
  letter-spacing: 1px;
  width: 18px;
}
.mux__output-value {
  font-size: 11px;
  color: #006080;
  font-weight: 700;
  letter-spacing: 0.5px;
}
</style>
