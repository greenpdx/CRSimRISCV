<template>
  <div class="ram">

    <div class="ram__header">
      <span class="ram__title">Data Memory</span>
      <span class="ram__subtitle">RAM · {{ words.length }} words</span>
    </div>

    <!-- Column headers -->
    <table class="ram__table">
      <thead>
        <tr class="ram__col-headers">
          <th class="ram__th ram__th--addr">Address</th>
          <th class="ram__th ram__th--bytes">Bytes</th>
          <th class="ram__th ram__th--dec">Dec</th>
          <th class="ram__th ram__th--dot"></th>
        </tr>
      </thead>
    </table>

    <!-- Scrollable body -->
    <div class="ram__scroll" ref="scrollEl">
      <table class="ram__table">
        <tbody>
          <MemoryRow
            v-for="(word, i) in words"
            :key="word.address"
            :word="word"
            kind="ram"
            :stripe="i % 2 === 1"
          />
        </tbody>
      </table>
    </div>

    <!-- Footer: last accessed address + value + operation -->
    <div class="ram__footer">
      <span
        class="ram__footer-op"
        :class="{
          'ram__footer-op--read':  lastOp === 'read',
          'ram__footer-op--write': lastOp === 'write',
          'ram__footer-op--idle':  lastOp === 'idle',
        }"
      >{{ lastOp }}</span>
      <span class="ram__footer-addr">{{ fmtHex(lastAddress) }}</span>
      <span class="ram__footer-val">{{ fmtHex(lastValue) }}</span>
    </div>

  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick } from 'vue'
import MemoryRow from '../rows/MemoryRow.vue'
import type { MemoryWord } from '../../../types/cpu'

export type RamOp = 'read' | 'write' | 'idle'

const props = defineProps<{
  /** Full RAM contents — all words, in address order */
  words: MemoryWord[]
  /** Last memory operation this cycle */
  lastOp: RamOp
  /** Address involved in the last operation */
  lastAddress: number
  /** Value read or written in the last operation */
  lastValue: number
}>()

const scrollEl = ref<HTMLDivElement | null>(null)

const fmtHex = (v: number) =>
  '0x' + (v >>> 0).toString(16).padStart(8, '0')

/** The word currently being accessed (active flag set by simulator) */
const activeWord = computed(() =>
  props.words.find(w => w.active) ?? null
)

/**
 * Auto-scroll to keep the active row visible on read/write.
 */
watch(activeWord, async () => {
  await nextTick()
  if (!scrollEl.value || !activeWord.value) return

  const rowIndex = props.words.findIndex(w => w.active)
  if (rowIndex < 0) return

  const rowH  = 18
  const viewH = scrollEl.value.clientHeight
  const target = rowIndex * rowH - viewH / 2 + rowH / 2

  scrollEl.value.scrollTo({ top: Math.max(0, target), behavior: 'smooth' })
})
</script>

<style scoped>
.ram {
  display: flex;
  flex-direction: column;
  background: #4ec3d5;
  border: 1.5px solid #2aacbe;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 300px;
}

/* Header */
.ram__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #2aacbe;
  padding: 4px 8px;
  flex-shrink: 0;
}
.ram__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.ram__subtitle {
  font-size: 9px;
  color: #c0eaf2;
}

/* Column headers */
.ram__table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}
.ram__col-headers {
  background: #3ab8cc;
}
.ram__th {
  padding: 2px 6px;
  font-size: 9px;
  font-weight: 500;
  letter-spacing: 1px;
  text-transform: uppercase;
  color: #d0f0f8;
  border-bottom: 1px solid #2aacbe;
  text-align: left;
}
.ram__th--addr  { width: 90px; }
.ram__th--bytes { width: 90px; }
.ram__th--dec   { }
.ram__th--dot   { width: 16px; }

/* Scrollable body */
.ram__scroll {
  flex: 1;
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 240px;
}

/* Footer */
.ram__footer {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 3px 8px;
  background: #2aacbe;
  min-height: 22px;
  flex-shrink: 0;
}
.ram__footer-op {
  font-size: 9px;
  padding: 1px 6px;
  border-radius: 2px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  min-width: 38px;
  text-align: center;
}
.ram__footer-op--idle  { background: #a0d8e4; color: #004050; }
.ram__footer-op--read  { background: #bde8ff; color: #004070; }
.ram__footer-op--write { background: #fff0b0; color: #604000; }

.ram__footer-addr {
  font-size: 10px;
  color: #ffffff;
  font-weight: 600;
}
.ram__footer-val {
  font-size: 10px;
  color: #c0eaf2;
}
</style>
