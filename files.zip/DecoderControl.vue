<template>
  <div class="ctrl" :class="{ 'ctrl--active': active }">

    <div class="ctrl__header">
      <span class="ctrl__title">Decoder / Control</span>
      <span class="ctrl__subtitle">{{ entry?.name ?? 'unknown' }} · {{ opcodeBin }}</span>
    </div>

    <div class="ctrl__body">

      <!-- Decoded instruction type + instructions -->
      <div class="ctrl__instr-row">
        <span class="ctrl__instr-type">{{ entry?.name ?? '?' }}</span>
        <span class="ctrl__instr-list">{{ entry?.instrs.join(' · ') ?? '—' }}</span>
      </div>

      <div class="ctrl__divider" />

      <!-- Control signals — grouped by destination -->
      <div class="ctrl__section-label">→ Register File</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="RegWrite" :value="signals.regWrite ? 1 : 0" />
      </div>

      <div class="ctrl__section-label">→ MUXes</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="ALUSrc"  :value="signals.aluSrc ? 1 : 0" :hint="signals.aluSrc ? 'imm' : 'rs2'" />
        <ControlSignalBadge label="WBSel"   :value="signals.wbSel"  :hint="WB_SEL_LABEL[signals.wbSel]" :bits="2" />
      </div>

      <div class="ctrl__section-label">→ ALU Control</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="ALUOp"   :value="signals.aluOp"  :hint="ALU_OP_LABEL[signals.aluOp]" :bits="2" />
      </div>

      <div class="ctrl__section-label">→ Data Memory</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="MemRead"  :value="signals.memRead  ? 1 : 0" />
        <ControlSignalBadge label="MemWrite" :value="signals.memWrite ? 1 : 0" />
      </div>

      <div class="ctrl__section-label">→ PC Logic</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="PCSel" :value="signals.pcSel" :hint="PC_SEL_LABEL[signals.pcSel]" :bits="2" />
      </div>

      <div class="ctrl__section-label">→ Imm Generator</div>
      <div class="ctrl__signals">
        <ControlSignalBadge label="ImmSel"  :value="signals.immSel" :hint="IMM_FORMAT_LABEL[entry?.immFormat ?? 'none']" :bits="3" />
      </div>

    </div>

  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import ControlSignalBadge from '../wiring/ControlSignalBadge.vue'
import {
  OPCODE_BY_VALUE,
  WB_SEL_LABEL,
  ALU_OP_LABEL,
  IMM_FORMAT_LABEL,
  PC_SEL_LABEL,
} from '../../../data/controlData'
import type { ControlSignals } from '../../../data/controlData'

const props = defineProps<{
  /** 7-bit opcode from instruction[6:0] */
  opcode: number
  /** True while decoding this cycle */
  active?: boolean
}>()

const entry = computed(() => OPCODE_BY_VALUE.get(props.opcode & 0x7f))

/** Binary string for header display */
const opcodeBin = computed(() =>
  (props.opcode & 0x7f).toString(2).padStart(7, '0')
)

/** Live control signals — default all-zero if opcode unknown */
const signals = computed<ControlSignals>(() =>
  entry.value?.signals ?? {
    regWrite: false, aluSrc: false, aluOp: 0,
    memRead:  false, memWrite: false,
    wbSel: 0, pcSel: 0, immSel: 5,
  }
)
</script>

<style scoped>
.ctrl {
  display: flex;
  flex-direction: column;
  background: #ffffff;
  border: 1.5px solid #cc2222;
  border-radius: 3px;
  overflow: hidden;
  font-family: 'JetBrains Mono', 'Courier New', monospace;
  min-width: 240px;
  transition: box-shadow 0.15s ease;
}
.ctrl--active {
  box-shadow: 0 0 0 2px #ff4444;
}

/* Header */
.ctrl__header {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  background: #cc2222;
  padding: 4px 8px;
}
.ctrl__title {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  color: #ffffff;
  text-transform: uppercase;
}
.ctrl__subtitle {
  font-size: 9px;
  color: #ffcccc;
}

/* Body */
.ctrl__body {
  padding: 5px 8px;
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.ctrl__instr-row {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.ctrl__instr-type {
  font-size: 11px;
  font-weight: 700;
  color: #cc2222;
  min-width: 52px;
}
.ctrl__instr-list {
  font-size: 8px;
  color: #888888;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.ctrl__divider {
  height: 1px;
  background: #f0d0d0;
  margin: 2px 0;
}

.ctrl__section-label {
  font-size: 8px;
  color: #cc2222;
  letter-spacing: 0.5px;
  margin-top: 2px;
  opacity: 0.7;
}
.ctrl__signals {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding-left: 4px;
}
</style>
